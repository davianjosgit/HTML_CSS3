Hi there, This font is for PERSONAL USE only :)
Please purchase the license before any commercial use, visit these following link : 

-->>> https://fontherapy.com/


EXTENDED COMMERCIAL LICENSE & CORPORATE LICENSE (For many users or big business like Game project, App, Television Broadcast, Movie/cinema)  are available. Please visit this link  --> https://fontherapy.com/  or Contact us at : typecoconut@gmail.com


Thank you :)
---------------------------------------------
CAUTION!
Anyone who uses personal use fonts for commercial without buying a commercial license and without permission from the author, will be fined $6000 USD
---------------------------------------------
menggunakan font ini untuk komersil tanpa membeli lisensinya dulu akan dikenakan 
biaya pelanggaran sebesar Rp 75.000.000 (tuju puluh lima juta rupiah)